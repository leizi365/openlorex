"""Wiki API application package."""
